//
//  songs.swift
//  carousel
//
//  Created by user on 6/9/23.
//

import SwiftUI

struct songs: Identifiable{
    var id: Int
    var title: String
    var image: String
}

var songData = [songs(id: 0, title: "", image: ""),
                songs(id: 1, title: "Taylor Swift", image: "taytay"),
                songs(id: 2, title: "SZA", image: "sza"),
                songs(id: 3, title: "The Weekend", image: "weekend"),
                songs(id: 4, title: "Ed Sheeran", image: "eddy"),
                songs(id: 5, title: "Nicki minaj", image: "niki"),
                songs(id: 6, title: "", image: "")]
