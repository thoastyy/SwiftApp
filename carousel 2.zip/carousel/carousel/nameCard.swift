//
//  nameCard.swift
//  carousel
//
//  Created by user on 6/9/23.
//

import SwiftUI

struct nameCard: View {
    var body: some View {
        VStack{
            Image("busker1")
                .resizable()
                .aspectRatio(contentMode: .fit) // Maintain aspect ratio and fit within the frame
                .frame(width: 300, height: 225) // Set the desired width and height
                .clipShape(Circle())
                
                Text("Jason Yu")
                    .bold()
                    .font(.system(size: 36))
            HStack(spacing: 30){
                bio1view()
                musicPlayer()
            }
                
        }
    }
}

struct nameCard_Previews: PreviewProvider {
    static var previews: some View {
        nameCard()
    }
}
