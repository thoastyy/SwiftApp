//
//  testSwipe.swift
//  carousel
//
//  Created by user on 7/9/23.
//

import SwiftUI

struct testSwipe: View {
    var body: some View {
        TabView{
            busker1View()
            busker2View()
            busker3View()
        }
        .tabViewStyle(.page)
    }
}

struct testSwipe_Previews: PreviewProvider {
    static var previews: some View {
        testSwipe()
    }
}
