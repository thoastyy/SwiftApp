import SwiftUI

struct SwipeView: View {
    @State private var currentIndex = 0
    let views: [AnyView] = [
        AnyView(busker1View()),
        AnyView(busker2View()),
        AnyView(busker3View())
    ]
    
    var body: some View {
        VStack {
            testSwipe()
        }
    }
}

struct FullScreenPageView<Content: View>: View {
    let content: Content
    
    var body: some View {
        ZStack {
            content
                .foregroundColor(.black)
        }
    }
}

struct SwipeView_Previews: PreviewProvider {
    static var previews: some View {
        SwipeView()
    }
}
