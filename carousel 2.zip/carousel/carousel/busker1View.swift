//
//  busker1View.swift
//  carousel
//
//  Created by user on 7/9/23.
//

import SwiftUI

struct busker1View: View {
    var body: some View {
        
        VStack{
            nameCard()
            Text("Songs Played")
                .padding(.top).bold()
                .font(.system(size: 25))
            carouselView(songName: " ")

        }
    }
}

struct busker1View_Previews: PreviewProvider {
    static var previews: some View {
        busker1View()
    }
}
