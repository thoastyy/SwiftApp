//
//  bio2view.swift
//  carousel
//
//  Created by user on 7/9/23.
//

import SwiftUI

struct bio2view: View {
    
    @State private var showSettings = false
    
    var body: some View {
        Button("View Bio") {
                    showSettings = true
                }
        .buttonStyle(.borderedProminent)
                .sheet(isPresented: $showSettings) {
                    settingsView()
                        .presentationDetents([.medium, .large])
                }
            }
    }

struct settingsView: View {
    var body: some View {
//
        Text("age🦸🏽‍♂️: 25\n\nbio🙈:\nBusking since 2020\nFull time working as a singer🎤 and song-writer\nMy trusty companion💋 is the saxophone🎷, which I play with heart and soul, crafting melodies that resonate with the rhythm of life🕺🏽.\nBusking isn't just a performance, it's an opportunity to connect with the heartbeat🌇 of the city. I'm here to share the joy of music and create memorable moments with each and every one of you.\nFeel free to snap photos or videos during my performances and tag me on your social media📱. Let's create memories together!\n\nlocation📍:\n1.295132, 103.851889\nCHJIMES\nhttps://maps.apple.com/?address=30%20Victoria%20St,%20Singapore%20187996&auid=6096130356827451565&ll=1.295132,103.851889&lsp=9902&q=CHIJMES")
            .fontWeight(.semibold)
            .multilineTextAlignment(.leading)
            .padding([.top, .leading, .trailing])
        
            
    }

}


struct bio2view_Previews: PreviewProvider {
    static var previews: some View {
        bio2view()
    }
}
