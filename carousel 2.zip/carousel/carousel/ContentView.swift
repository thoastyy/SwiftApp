//
//  ContentView.swift
//  carousel
//
//  Created by user on 6/9/23.
//

import SwiftUI
import MediaPlayer

struct ContentView: View {
    var body: some View {
        VStack {
            SwipeView()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group{
            ContentView()
                .environment(\.colorScheme, .dark)
            ContentView()
                .environment(\.colorScheme, .light)
        }
    }
}
