//
//  busker2View.swift
//  carousel
//
//  Created by user on 7/9/23.
//

import SwiftUI

struct busker2View: View {
    var body: some View {
        VStack{
            nameCard2()
            Text("Upcoming")
                .padding(.top).bold()
                .font(.system(size: 25))
            carouselView(songName: " ")
            
        }
        
    }
}

struct busker2View_Previews: PreviewProvider {
    static var previews: some View {
        busker2View()
    }
}
