//
//  nameCard3.swift
//  carousel
//
//  Created by user on 7/9/23.
//

import SwiftUI

struct nameCard3: View {
    var body: some View {
        
        VStack{
            Image("busker3")
                .resizable()
                .aspectRatio(contentMode: .fit) // Maintain aspect ratio and fit within the frame
                .frame(width: 300, height: 225) // Set the desired width and height
                .clipShape(Circle())
                Text("Arya Yunata")
                    .bold()
                    .font(.system(size: 36))
            HStack(spacing: 30){
                bio3view()
                musicPlayer()
            }
        }
    }
}

struct nameCard3_Previews: PreviewProvider {
    static var previews: some View {
        nameCard3()
    }
}
