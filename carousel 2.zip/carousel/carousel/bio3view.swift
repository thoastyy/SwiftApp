//
//  bio3view.swift
//  carousel
//
//  Created by user on 7/9/23.
//

import SwiftUI

struct bio3view: View {
    @State private var showSettings = false
    var body: some View {
            Button("View Bio") {
                showSettings = true
            }
            .buttonStyle(.borderedProminent)
            .sheet(isPresented: $showSettings) {
                SettingView()
                    .presentationDetents([.medium, .large])
            }
    }
}

struct SettingView: View {
    var body: some View {
//
        Text("age👩🏻‍💻: 23\n\nbio🧩:\nBusking since 2018\nPart time apple🍎 employee, part time busker\nWith my violin🎻 in hand, I craft musical stories that evoke emotions😍 and ignite your imagination, creating a symphony in the midst of the city's chaos.\nIf my music resonates with you, consider dropping a coin or two in my hat to keep the musical river flowing. Every contribution, big or small, fuels my passion.\nIf you're in need of a musical escape or a dance partner under the open sky, come find me on the streets, and let's weave melodies into the tapestry of city life. See you on the sidewalk!\n\nlocation📍:\n1.300490, 103.854954\nBugis street\nhttps://maps.apple.com/?address=3%20New%20Bugis%20Street,%20Singapore%20188867&auid=16902182123188571335&ll=1.300490,103.854954&lsp=9902&q=Bugis%20Street")
            .fontWeight(.semibold)
            .multilineTextAlignment(.leading)
            .padding([.top, .leading, .trailing])
        
            
    }

}

struct bio3view_Previews: PreviewProvider {
    static var previews: some View {
        bio3view()
    }
}
