//
//  busker3View.swift
//  carousel
//
//  Created by user on 7/9/23.
//

import SwiftUI

struct busker3View: View {
    var body: some View {
        VStack{
            nameCard3()
            Text("Songs that I will be playing")
                .padding(.top).bold()
                .font(.system(size: 25))
            carouselView(songName: " ")
            
        }
    }
}

struct busker3View_Previews: PreviewProvider {
    static var previews: some View {
        busker3View()
    }
}
