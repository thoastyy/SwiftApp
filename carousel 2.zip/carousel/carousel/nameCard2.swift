//
//  nameCard2.swift
//  carousel
//
//  Created by user on 7/9/23.
//

import SwiftUI

struct nameCard2: View {
    var body: some View {
        VStack{
            Image("busker2")
                .resizable()
                .aspectRatio(contentMode: .fit) // Maintain aspect ratio and fit within the frame
                .frame(width: 300, height: 225) // Set the desired width and height
                .clipShape(Circle())
            
            
            Text("Muhammad Firdaus")
                .bold()
                .font(.system(size: 36))
            
            HStack(spacing: 30){
                bio2view()
                musicPlayer()
            }
            
        }
    }
    
    struct nameCard2_Previews: PreviewProvider {
        static var previews: some View {
            nameCard2()
        }
    }
}
