//
//  carouselApp.swift
//  carousel
//
//  Created by user on 6/9/23.
//

import SwiftUI

@main
struct carouselApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()            
        }
    }
}
